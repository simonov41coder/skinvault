package com.simonov.skinvault.client

import net.fabricmc.api.ClientModInitializer

object SkinvaultClient : ClientModInitializer {
	override fun onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}